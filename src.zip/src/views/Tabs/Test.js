export default class Test extends  React.PureComponent{
    constructor(props) {
       super(props);

    }

   render() {
    return (
        <div>
             <p> Hi </p>
        </div>
    );

        
}
}