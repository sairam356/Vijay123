import * as React from 'react';
import EventEmitter from "react-native-eventemitter"; 
import _ from 'lodash';

import classnames from 'classnames';

import TableComponent  from './TableComponent'; 


import axios from 'axios';
import { Container,Alert,Nav,NavItem,FormGroup,Label, Badge,Row,Col,Card,CardHeader,FormText,CardBlock,Button,Modal, ModalHeader, ModalBody, ModalFooter,Input, InputGroup, InputGroupAddon } from "reactstrap";

const getRowId = row => row.id;
 class MM extends React.Component{
    constructor(props) {
    super(props);

    this.state = {
      activeTab: '1',
      displayTable:false,
      displayAdvanceNoticeTable:false,
      dropData:[
           {
             "plant":"test",
             "sloc":"test1"


           },
           {
                "plant":"test1",
                "sloc":"test2"
           },
           {
                "plant":"test1",
                "sloc":"test2"
           }
           ],
        columns: [
     
      ],
       tableColumnExtensions: [
        { columnName: 'car', width: 300  },
      ],
      rows:[],
      editIdx: -1,
      data:[ {
        firstName: "Tann",
        lastName: "Gounin",
        username: "tgounin0",
        email: "tgounin0@wordpress.com",
        passsword: "yJG2MuL5piY",
         editStatus: "N"
      },
      {
        firstName: "Elana",
        lastName: "Ricioppo",
        username: "ericioppo1",
        email: "ericioppo1@timesonline.co.uk",
        passsword: "S7p9ReUoQe",
         editStatus: "N"
      },
      {
        firstName: "Bentlee",
        lastName: "Decourt",
        username: "bdecourt2",
        email: "bdecourt2@about.me",
        passsword: "MWU9hc",
         editStatus: "N"
      },
      {
        firstName: "Hyacintha",
        lastName: "Choudhury",
        username: "hchoudhury3",
        email: "hchoudhury3@va.gov",
        passsword: "kRtWP1",
         editStatus: "N"
      },
      {
        firstName: "Ari",
        lastName: "Spedroni",
        username: "aspedroni4",
        email: "aspedroni4@sun.com",
        passsword: "o78ibUPPmDlZ",
         editStatus: "Y"
      },
      {
        firstName: "Abelard",
        lastName: "Rodriguez",
        username: "arodriguez5",
        email: "arodriguez5@shutterfly.com",
        passsword: "g2jd4AwfpA",
         editStatus: "Y"
      },
      {
        firstName: "Ikey",
        lastName: "Latek",
        username: "ilatek6",
        email: "ilatek6@berkeley.edu",
        passsword: "GAsgPpKvJx",
         editStatus: "Y"
      },
      {
        firstName: "Justis",
        lastName: "Habbeshaw",
        username: "jhabbeshaw7",
        email: "jhabbeshaw7@simplemachines.org",
        passsword: "GN2aQt3ZPq",
         editStatus: "Y"
      },
      {
        firstName: "Maddie",
        lastName: "Bayne",
        username: "mbayne8",
        email: "mbayne8@constantcontact.com",
        passsword: "H1GmQcyG6",
         editStatus: "Y"
      },
      {
        firstName: "Gerrie",
        lastName: "Rulton",
        username: "grulton9",
        email: "grulton9@reverbnation.com",
        passsword: "tcwp6oONe",
        editStatus: "Y"
      }]
     
  }
}
handleRemove = i => {
    this.setState(state => ({
      data: state.data.filter((row, j) => j !== i)
    }));
  };

  startEditing = i => {
    this.setState({ editIdx: i });
  };

  stopEditing = () => {
    this.setState({ editIdx: -1 });
  };

  handleSave = (i, x) => {
    this.setState(state => ({
      data: state.data.map((row, j) => (j === i ? x : row))
    }));
    this.stopEditing();
  };


   render() {
       const { rows, columns,tableColumnExtensions,selection } = this.state;
    return (
      <div>

           <TableComponent   
            handleRemove={this.handleRemove}
            startEditing={this.startEditing}
            editIdx={this.state.editIdx}
            stopEditing={this.stopEditing}
            handleSave={this.handleSave}
            
            data={this.state.data}
            header={[
              {
                name: "First name",
                prop: "firstName"
              },
              {
                name: "Last name",
                prop: "lastName"
              },
              {
                name: "Username",
                prop: "username"
              },
              {
                name: "Email",
                prop: "email"
              },
              {
                  name:"Status",
                  prop:"editStatus"
              }
            ]}/>

  </div>
    );
  }
}

export default MM;